/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dye.micheal.supermarket.testharness;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Administrator
 */
public class Supermarkettestharness {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        
        
        String connectionUrl = "";
        try {
            Class.forName("mySQL.jdbc.driver.blahaha");
            Connection conn = DriverManager.getConnection(connectionUrl);
            
            PreparedStatement ps = conn.prepareStatement("SELECT ProductId, ProductName FROM PRODCUT");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String name = rs.getString("ProductName");
                System.out.println(name);
            }
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Supermarkettestharness.class.getClass()).log(Level.SEVERE, nill, ex);
        } catch
        // TODO code application logic here
    }
    
}
